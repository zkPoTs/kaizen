#define MCL_BINT_ASM 0
#include <mcl/bls12_381.hpp>

int main()
{
	mcl::bn::initPairing(mcl::BLS12_381);
}

