#include <mcl/bls12_381.hpp>
using namespace mcl::bls12;
#define MCLBN_DEFINE_STRUCT
#define MCLBN_FP_UNIT_SIZE 6
#define MCLBN_FR_UNIT_SIZE 4
#include "bn_c_test.hpp"

